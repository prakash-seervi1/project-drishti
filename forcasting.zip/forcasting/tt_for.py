from google.cloud import aiplatform

aiplatform.init(
    project="project-drishti-mvp-31f1b",
    location="us-central1"
)

dataset = aiplatform.TabularDataset.create(
    display_name="crowd_forecasting_dataset",
    bq_source="bq://project-drishti-mvp-31f1b.drishti_analytics.training_data",
)

print("Created dataset:", dataset.resource_name)

