from google.cloud import aiplatform

aiplatform.init(
    project="project-drishti-mvp-31f1b",
    location="us-central1"
)

bq_source = "bq://project-drishti-mvp-31f1b.drishti_analytics.crowd_history"

dataset = aiplatform.TabularDataset.create(
    display_name="crowd_forecast_sdk_dataset",
    bq_source=bq_source,
)

print(f"✅ Created dataset: {dataset.resource_name}")

