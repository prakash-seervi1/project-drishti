from google.cloud import aiplatform

# --- Configuration ---
project = "project-drishti-mvp-31f1b"
location = "us-central1"
# Your confirmed dataset_name:
dataset_name = "projects/268678901849/locations/us-central1/datasets/6597349592365268992"
model_display_name = "crowd-forecast-tabular-model-v1"

# Initialize Vertex AI client
aiplatform.init(project=project, location=location)

# Load the dataset
dataset = aiplatform.TabularDataset(dataset_name=dataset_name)

# --- Define the AutoML Forecasting Training Job ---
# No column_transformations here, relying on auto-detection by AutoML
job = aiplatform.AutoMLForecastingTrainingJob(
    display_name="crowd_forecast_v1",
    optimization_objective="minimize-rmse", # Common objective for forecasting
)

# --- Run the Training Job ---
# Pass all forecasting-specific parameters to the .run() method
model = job.run(
    dataset=dataset,
    model_display_name=model_display_name,
    target_column="peopleCount",                  # The column you want to predict
    time_column="timestamp",                      # The time series column
    time_series_identifier_column="zoneId",       # Column identifying individual time series
    # These columns are NOT known for future predictions (like the target itself)
    unavailable_at_forecast_columns=["peopleCount"],
    # These columns ARE known for future predictions (like zone ID)
    available_at_forecast_columns=["zoneId"],
    forecast_horizon=12,                          # Predict 12 future intervals (e.g., 12 * 5 minutes = 1 hour)
    context_window=24,                            # Use 24 past intervals as context
    data_granularity_unit="minute",
    data_granularity_count=5,                     # Data points every 5 minutes
    budget_milli_node_hours=1000,                 # Budget for training (1000 milli-node hours = 1 node hour)
    # No column_transformations parameter here either
)

# --- Output Training Job Status ---
print(f"✅ Training started. Model resource name: {model.resource_name}")
print(f"You can monitor the training job at: https://console.cloud.google.com/vertex-ai/locations/{location}/training/{model.name.split('/')[-1]}?project={project}")
