import os
import logging
from google.cloud import aiplatform
from google.api_core import exceptions
from google.oauth2 import service_account

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize AI Platform with explicit service account credentials
try:
    credentials = service_account.Credentials.from_service_account_file(
        "/home/prakash63kumar/gcp-crowd-agents/drishti-api-access.json",
        scopes=["https://www.googleapis.com/auth/cloud-platform"],
    )
    logger.info(f"Using credentials: {credentials}")
    aiplatform.init(
        project="project-drishti-mvp-31f1b",
        location="us-central1",
        credentials=credentials,
    )
    logger.info("✅ Initialized AI Platform successfully.")

    # Use existing tabular dataset (for reference, but pipeline creates its own)
    dataset = aiplatform.TabularDataset(
        "projects/268678901849/locations/us-central1/datasets/846185798003851264"
    )
    logger.info(f"✅ Using existing tabular dataset: {dataset.resource_name}")

    # Define the pipeline parameters
    pipeline_parameters = {
        "project": "project-drishti-mvp-31f1b",
        "location": "us-central1",
        "dataset_bq_source": "bq://project-drishti-mvp-31f1b.drishti_analytics.training_data",
        "display_name": "drishti-forecasting-job",
        "target_column": "peopleCount",
    }

    # Run the pipeline using the custom template
    pipeline_job = aiplatform.PipelineJob(
        display_name="drishti-forecasting-pipeline",
        template_path="gs://project-drishti-mvp-31f1b-test/pipeline_root/drishti_forecasting_pipeline.yaml",
        parameter_values=pipeline_parameters,
        project="project-drishti-mvp-31f1b",
        location="us-central1",
        credentials=credentials,
    )

    pipeline_job.run(sync=True)
    logger.info("✅ Forecasting pipeline job completed successfully.")

    # Retrieve the trained model
    pipeline_job_output = pipeline_job.get_output_artifacts()
    model_resource_name = None
    for artifact in pipeline_job_output:
        if artifact.metadata.get("model_resource_name"):
            model_resource_name = artifact.metadata["model_resource_name"]
            break

    if not model_resource_name:
        raise ValueError("Model resource name not found in pipeline output.")

    model = aiplatform.Model(model_resource_name, credentials=credentials)
    logger.info(f"✅ Retrieved trained model: {model_resource_name}")

    # Create an endpoint
    endpoint = aiplatform.Endpoint.create(
        display_name="drishti-forecast-endpoint",
        project="project-drishti-mvp-31f1b",
        location="us-central1",
        credentials=credentials,
    )
    logger.info(f"✅ Created endpoint: {endpoint.resource_name}")

    # Deploy the model to the endpoint
    model.deploy(
        endpoint=endpoint,
        machine_type="n1-standard-2",
        min_replica_count=1,
        max_replica_count=1,
        traffic_split={"0": 100},
    )
    logger.info("✅ Model deployed to endpoint successfully.")
    print(f"Deployed endpoint: {endpoint.resource_name}")

except exceptions.GoogleAPIError as e:
    logger.error(f"Google API Error: {e}")
    raise
except Exception as e:
    logger.error(f"Unexpected error: {e}")
    raise