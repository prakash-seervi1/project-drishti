from google.cloud import aiplatform

# 🔁 Replace with your project details
PROJECT_ID = "project-drishti-mvp-31f1b"
REGION = "us-central1"
DISPLAY_NAME = "crowd_forecasting_dataset"
BQ_SOURCE = "bq://project-drishti-mvp-31f1b.drishti_analytics.training_data"

# Step 1: Initialize Vertex AI client
aiplatform.init(project=PROJECT_ID, location=REGION)

# Step 2: Create the Tabular dataset from BigQuery
dataset = aiplatform.TabularDataset.create(
    display_name=DISPLAY_NAME,
    bq_source=BQ_SOURCE,
)

# Step 3: Output the resource name
print("✅ Dataset created successfully!")
print("Resource name:", dataset.resource_name)

