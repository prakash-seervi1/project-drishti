import kfp
from kfp import dsl
from google_cloud_pipeline_components.v1.automl.training_job import AutoMLTabularTrainingJobRunOp
from google_cloud_pipeline_components.v1.endpoint import EndpointCreateOp, ModelDeployOp
from google_cloud_pipeline_components.v1.dataset import TabularDatasetCreateOp

# Define pipeline
@kfp.dsl.pipeline(
    name="drishti-forecasting-pipeline",
    pipeline_root="gs://project-drishti-mvp-31f1b-test/pipeline_root/"
)
def pipeline(
    project: str,
    location: str,
    dataset_bq_source: str,
    display_name: str,
    target_column: str,
):
    # Use TabularDatasetCreateOp to create a dataset object
    dataset_op = TabularDatasetCreateOp(
        project=project,
        location=location,
        display_name="drishti-tabular-dataset",
        bq_source=dataset_bq_source,
    )

    training_op = AutoMLTabularTrainingJobRunOp(
        project=project,
        location=location,
        display_name=display_name,
        optimization_prediction_type="regression",
        optimization_objective="minimize-rmse",
        dataset=dataset_op.outputs["dataset"],
        target_column=target_column,
        column_transformations=[
            {"numeric": {"column_name": "peopleCount"}},
            {"timestamp": {"column_name": "timestamp"}},
            {"categorical": {"column_name": "day_of_week"}},
            {"numeric": {"column_name": "hour_of_day"}},
            {"numeric": {"column_name": "lag_peopleCount_1"}},
            {"numeric": {"column_name": "rolling_avg_5min"}},
            {"categorical": {"column_name": "crowdDensity"}},
        ],
        training_fraction_split=0.8,
        validation_fraction_split=0.1,
        test_fraction_split=0.1,
        budget_milli_node_hours=1000,
        export_evaluated_data_items=True,
    )

    endpoint_op = EndpointCreateOp(
        project=project,
        location=location,
        display_name="drishti-forecast-endpoint",
    )

    deploy_op = ModelDeployOp(
        model=training_op.outputs["model"],
        endpoint=endpoint_op.outputs["endpoint"],
        dedicated_resources_machine_type="n1-standard-2",
        dedicated_resources_min_replica_count=1,
        dedicated_resources_max_replica_count=1,
        traffic_split={"0": 100},
    )

# Compile pipeline to YAML
compiler = kfp.compiler.Compiler()
compiler.compile(
    pipeline_func=pipeline,
    package_path="drishti_forecasting_pipeline.yaml"
)