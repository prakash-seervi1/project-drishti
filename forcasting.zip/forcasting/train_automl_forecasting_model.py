import os
import logging
from google.cloud import aiplatform
from google.api_core import exceptions

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize AI Platform
try:
    aiplatform.init(
        project="project-drishti-mvp-31f1b",
        location="us-central1",
    )
    logger.info("✅ Initialized AI Platform successfully.")

    # Create a new time-series dataset from BigQuery
    dataset = aiplatform.TimeSeriesDataset.create(
        display_name="drishti-time-series-dataset",
        bq_source="bq://project-drishti-mvp-31f1b.drishti_analytics.training_data",
        project="project-drishti-mvp-31f1b",
        location="us-central1",
    )
    logger.info(f"✅ Created time-series dataset: {dataset.resource_name}")

    # Configure forecasting job
    forecasting_job = aiplatform.AutoMLForecastingTrainingJob(
        display_name="drishti-forecasting-job",
        optimization_objective="minimize-rmse",
        column_specs={
            "peopleCount": "numeric",
            "timestamp": "timestamp",
            "day_of_week": "categorical",
            "hour_of_day": "numeric",
            "lag_peopleCount_1": "numeric",
            "rolling_avg_5min": "numeric",
            "crowdDensity": "categorical",
        },
    )

    # Run forecasting job
    model = forecasting_job.run(
        dataset=dataset,
        model_display_name="drishti-forecast-model",
        target_column="peopleCount",
        time_column="timestamp",
        time_series_identifier_column="zoneId",
        unavailable_at_forecast_columns=["peopleCount", "lag_peopleCount_1", "rolling_avg_5min", "crowdDensity"],
        available_at_forecast_columns=["timestamp", "day_of_week", "hour_of_day"],
        forecast_horizon=10,
        context_window=30,
        data_granularity_unit="minute",
        data_granularity_count=1,
        training_fraction_split=0.8,
        validation_fraction_split=0.1,
        test_fraction_split=0.1,
        budget_milli_node_hours=1000,
        export_evaluated_data_items=True,
    )
    logger.info("✅ Forecasting model training completed successfully.")
    print(f"Trained model: {model.resource_name}")

    # Create an endpoint
    endpoint = aiplatform.Endpoint.create(
        display_name="drishti-forecast-endpoint",
        project="project-drishti-mvp-31f1b",
        location="us-central1",
    )
    logger.info(f"✅ Created endpoint: {endpoint.resource_name}")

    # Deploy the model to the endpoint
    model.deploy(
        endpoint=endpoint,
        machine_type="n1-standard-2",  # Minimum machine type for AutoML models
        min_replica_count=1,
        max_replica_count=1,
        traffic_split={"0": 100},  # Direct all traffic to this model
    )
    logger.info("✅ Model deployed to endpoint successfully.")
    print(f"Deployed endpoint: {endpoint.resource_name}")

except exceptions.GoogleAPIError as e:
    logger.error(f"Google API Error: {e}")
    raise
except Exception as e:
    logger.error(f"Unexpected error: {e}")
    raise
