from google.cloud import firestore
from typing import Dict, List, Any, Optional
from datetime import datetime
from tools.tool_logging import log_tool_call

db = firestore.Client()

@log_tool_call("fetch_incidents")
def fetch_incidents() -> List[Dict]:
    """Fetches all incidents from Firestore."""
    return [dict(id=doc.id, **doc.to_dict()) for doc in db.collection('incidents').stream()]

@log_tool_call("get_active_incidents")
def get_active_incidents() -> Dict[str, Any]:
    """Return all incidents whose status is not 'close'."""
    all_incidents = fetch_incidents()
    active = [i for i in all_incidents if i.get('status') != 'close']
    return {"status": "success", "incidents": active}

@log_tool_call("fetch_zones")
def fetch_zones() -> List[Dict]:
    """Fetches all zones from Firestore."""
    return [dict(id=doc.id, **doc.to_dict()) for doc in db.collection('zones').stream()]

@log_tool_call("fetch_responders")
def fetch_responders() -> List[Dict]:
    """Fetches all responders from Firestore."""
    return [dict(id=doc.id, **doc.to_dict()) for doc in db.collection('responders').stream()]

@log_tool_call("get_available_responders")
def get_available_responders() -> Dict[str, Any]:
    """Return only responders whose latest status event is 'available'.
    NOTE: No timestamp ordering; just uses the first event found for now."""
    responders = [dict(id=doc.id, **doc.to_dict()) for doc in db.collection('responders').stream()]
    available = []
    for responder in responders:
        responder_id = responder.get('id')
        # Fetch all events for this responder (no ordering)
        all_events = list(db.collection('responder_status_updates')\
            .where('responderId', '==', responder_id)\
            .stream())
        print(f"[DEBUG] All events for responder {responder_id}: {[e.to_dict() for e in all_events]}")
        latest_event = all_events[0] if all_events else None
        if latest_event:
            event_data = latest_event.to_dict()
            print(f"[DEBUG] Responder {responder_id} event used: {event_data}")
            if event_data.get('status') == 'available':
                available.append(responder)
        else:
            print(f"[DEBUG] Responder {responder_id} has no status events.")
    print(f"[DEBUG] Available responders: {available}")
    return {"status": "success", "responders": available}

@log_tool_call("fetch_alerts")
def fetch_alerts() -> List[Dict]:
    """Fetches all alerts from Firestore."""
    return [dict(id=doc.id, **doc.to_dict()) for doc in db.collection('alerts').stream()]

@log_tool_call("analyze_responder_assignments")
def analyze_responder_assignments() -> Dict[str, Any]:
    """Analyzes all responders in the system."""
    responders_ref = db.collection('responders')
    available_query = responders_ref.where('status', '==', 'available')
    available_docs = available_query.stream()
    available = [doc.id for doc in available_docs]
    responders = responders_ref.stream()
    assigned = {}
    for doc in responders:
        data = doc.to_dict()
        if data.get('assignedIncident'):
            assigned[data.get('assignedIncident')] = doc.id
    return {"available": available, "assigned": assigned}

@log_tool_call("assign_responder_to_incident")
def assign_responder_to_incident(incident_id: str, responder_id: Optional[str] = None) -> Dict[str, str]:
    """Assigns a responder to the specified incident by writing an event to responder_status_updates.
    If responder_id is not provided, picks the first available responder."""
    if responder_id is None:
        available = get_available_responders().get('responders', [])
        if not available:
            return {"status": "error", "message": "No available responder found"}
        responder_id = available[0]['id']
    # Get incident info for zoneId
    incident_ref = db.collection('incidents').document(incident_id)
    incident_doc = incident_ref.get()
    if not incident_doc.exists:
        return {"status": "error", "message": "Incident not found"}
    incident = incident_doc.to_dict()
    zone_id = incident.get("zoneId")
    status_update = {
        "responderId": responder_id,
        "incidentId": incident_id,
        "zoneId": zone_id,
        "status": "assigned",
        "action": "assigned_to_incident",
        "timestamp": firestore.SERVER_TIMESTAMP
    }
    # Write to event log (history)
    db.collection('responder_status_updates_history').add(status_update)
    # Write to latest status (deduplication)
    db.collection('responder_status_updates').document(responder_id).set(status_update)
    return {"status": "assigned", "responder_id": responder_id, "incident_id": incident_id, "zone_id": zone_id}

@log_tool_call("assign_any_responder_to_incident")
def assign_any_responder_to_incident(incident_id: str) -> Dict[str, Any]:
    available = get_available_responders().get('responders', [])
    if not available:
        return {"status": "error", "error_message": "No responders available"}
    responder_id = available[0]['id']
    return assign_responder_to_incident(incident_id, responder_id)

@log_tool_call("assign_responder_to_zone")
def assign_responder_to_zone(responder_id: str, zone_id: str) -> Dict[str, str]:
    """Assigns a responder to a zone by writing an event to responder_status_updates."""
    responders_ref = db.collection('responders')
    zones_ref = db.collection('zones')
    responder_doc = responders_ref.document(responder_id)
    zone_doc = zones_ref.document(zone_id)
    responder = responder_doc.get()
    zone = zone_doc.get()
    if not responder.exists or not zone.exists:
        return {"status": "error", "message": "Responder or zone not found"}
    responder_data = responder.to_dict()
    if responder_data.get("status") != "available":
        return {"status": "error", "message": f"Responder {responder_id} is not available (current status: {responder_data.get('status')})"}
    status_update = {
        "responderId": responder_id,
        "zoneId": zone_id,
        "status": "assigned",
        "action": "assigned_to_zone",
        "timestamp": firestore.SERVER_TIMESTAMP
    }
    db.collection('responder_status_updates_history').add(status_update)
    db.collection('responder_status_updates').document(responder_id).set(status_update)
    return {"status": "assigned", "responder_id": responder_id, "zone_id": zone_id}

@log_tool_call("assign_any_responder_to_zone")
def assign_any_responder_to_zone(zone_id: str) -> Dict[str, Any]:
    """Assign any available responder to the given zone by writing an event to responder_status_updates."""
    available = get_available_responders().get('responders', [])
    if not available:
        return {"status": "error", "error_message": "No responders available"}
    responder_id = available[0]["id"]
    return assign_responder_to_zone(responder_id, zone_id)

@log_tool_call("notify_unavailable")
def notify_unavailable(zone_id: str) -> Dict[str, str]:
    """Logs an alert in Firestore if no responder is available for a zone (event-driven)."""
    # This function does not have a responder_id, so only .add() is used
    db.collection('responder_status_updates').add({
        "zoneId": zone_id,
        "status": "unavailable",
        "action": "no_responder_available",
        "timestamp": firestore.SERVER_TIMESTAMP
    })
    return {"status": "notified", "zone_id": zone_id, "method": "event_logged"}

@log_tool_call("suggest_zones_needing_responders")
def suggest_zones_needing_responders() -> Dict[str, Any]:
    """Suggest zones that need more responders based on incidents and current assignments. Placeholder logic."""
    incidents = fetch_incidents()
    zones = fetch_zones()
    needs = []
    for inc in incidents:
        if inc.get('status') == 'active':
            needs.append(inc.get('zoneId'))
    return {"status": "success", "zones_needing_responders": list(set(needs))}

@log_tool_call("get_incident_by_id")
def get_incident_by_id(incident_id: str) -> dict:
    doc = db.collection('incidents').document(incident_id).get()
    if not doc.exists:
        raise HTTPException(status_code=404, detail="Incident not found")
    return dict(id=doc.id, **doc.to_dict())

@log_tool_call("get_incidents_by_status")
def get_incidents_by_status(status: str) -> dict:
    docs = db.collection('incidents').where('status', '==', status).stream()
    incidents = [dict(id=doc.id, **doc.to_dict()) for doc in docs]
    return {"incidents": incidents}

@log_tool_call("get_incidents_by_zone")
def get_incidents_by_zone(zone_id: str) -> dict:
    docs = db.collection('incidents').where('zoneId', '==', zone_id).stream()
    incidents = [dict(id=doc.id, **doc.to_dict()) for doc in docs]
    return {"incidents": incidents} 